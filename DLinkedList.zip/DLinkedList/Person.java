
/**
 * Write a description of class Person here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Person
{
    // instance variables - replace the example below with your own
    private String firstName;
    private String lastName;
    private int id;
    
    /**
     * Constructor for objects of class Person
     */
    public Person(String firstName, String lastName, int id)
    {
        // initialise instance variables
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public int getId(){
        return id;
    }
    
    public String toString(){
        return "Name: " + getFirstName() + " " + getLastName() + " Id: " + getId();
    }
}
