
/**
 * Write a description of interface LinkedList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface LinkedList<E>
{
    /**
     * An example of a method header - replace this comment with your own
     *
     * @param  y a sample parameter for a method
     * @return   the result produced by sampleMethod
     */
    
    void add(int index, E data);
    
    void addFirst(E e);
    
    void addLast(E e);
    
    void delete(int index);
    
    void deleteFirst();
    
    void deleteLast();
    
    int size();
    
    //void clear();
    
    //boolean contains();

}
